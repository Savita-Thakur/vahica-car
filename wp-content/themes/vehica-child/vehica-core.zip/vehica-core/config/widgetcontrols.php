<?php
/**
 * Element controls
 */

if (!defined('ABSPATH')) {
    exit;
}

return [
    \Vehica\Widgets\Controls\SelectRemoteControl::TYPE => \Vehica\Widgets\Controls\SelectRemoteControl::class
];