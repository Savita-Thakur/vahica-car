<?php

get_header();

do_action('vehica/layouts/archive/car');

get_footer();