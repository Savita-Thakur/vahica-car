<?php if (!empty(vehicaApp('short_info'))) : ?>
    <div class="vehica-short-info">
        <div class="vehica-short-info__inner">
            <?php echo esc_html(vehicaApp('short_info')); ?>
        </div>
    </div>
<?php endif; ?>