<?php
/* @var \Vehica\Components\Menu\MenuLevel $vehicaMenuLevel */
global $vehicaMenuLevel;
?>
<div class="<?php echo esc_attr($vehicaMenuLevel->getClass()); ?>">