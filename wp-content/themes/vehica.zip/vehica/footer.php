<?php
//get_template_part('templates/chat/chat');
?>
<?php wp_footer(); ?>
</body>
</html>