<div class="clearfix"></div>
<div class="vehica-edit__section-title">
    <h1>{{ field.name }}</h1>
</div>
<div class="clearfix"></div>