<?php
dynamic_sidebar( 'ulisting_inventory_sidebar' );