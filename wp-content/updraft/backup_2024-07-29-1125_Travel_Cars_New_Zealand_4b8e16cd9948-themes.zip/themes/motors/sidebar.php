<?php
if ( is_active_sidebar( 'default' ) ) {
	dynamic_sidebar( 'default' );
}
